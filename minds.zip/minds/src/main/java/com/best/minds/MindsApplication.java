package com.best.minds;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MindsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MindsApplication.class, args);
	}

}
